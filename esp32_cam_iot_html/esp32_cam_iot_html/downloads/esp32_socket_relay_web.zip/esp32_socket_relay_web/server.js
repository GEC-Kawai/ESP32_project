const net = require("net");
const http = require("http");
const fs = require("fs");
const path = require("path");
const WebSocket = require("ws");

const HTTP_PORT = Number(process.env.HTTP_PORT || 3000);
const TCP_PORT = Number(process.env.TCP_PORT || 5000);
const HOST = process.env.HOST || "0.0.0.0";
const PUBLIC_DIR = path.join(__dirname, "public");

let esp32Socket = null;
let esp32Buffer = "";

let latestStatus = {
  state: "DISCONNECTED",
  wifi_connected: false,
  motion_detected: false,
  light_level: 0,
  capture_count: 0,
  last_capture_result: "NONE",
  error_code: 0
};

let latestDevice = {
  connected: false,
  device_id: "",
  fw_version: "",
  remote_address: "",
  connected_at: "",
  last_received_at: ""
};

const clients = new Set();

function nowIso() {
  return new Date().toISOString();
}

function log(...args) {
  console.log(`[${nowIso()}]`, ...args);
}

function broadcastToWeb(type, payload) {
  const message = JSON.stringify({ type, payload });
  for (const ws of clients) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(message);
    }
  }
}

function sendToEsp32(message) {
  if (!esp32Socket || esp32Socket.destroyed) return false;
  esp32Socket.write(JSON.stringify(message) + "\n", "utf8");
  return true;
}

function updateLatestStatus(message) {
  latestStatus = {
    state: message.state ?? latestStatus.state,
    wifi_connected: Boolean(message.wifi_connected),
    motion_detected: Boolean(message.motion_detected),
    light_level: Number(message.light_level ?? 0),
    capture_count: Number(message.capture_count ?? latestStatus.capture_count),
    last_capture_result: message.last_capture_result ?? latestStatus.last_capture_result,
    error_code: Number(message.error_code ?? 0)
  };
  latestDevice.last_received_at = nowIso();
  broadcastToWeb("status", latestStatus);
  broadcastToWeb("device", latestDevice);
}

function handleEsp32Message(message) {
  if (!message || typeof message.type !== "string") return;

  switch (message.type) {
    case "hello":
      latestDevice = {
        ...latestDevice,
        connected: true,
        device_id: message.device_id || "",
        fw_version: message.fw_version || "",
        last_received_at: nowIso()
      };
      broadcastToWeb("device", latestDevice);
      break;

    case "status":
      updateLatestStatus(message);
      break;

    case "capture_result":
      latestStatus.capture_count = Number(message.capture_count ?? latestStatus.capture_count);
      latestStatus.last_capture_result = message.result || latestStatus.last_capture_result;
      latestStatus.error_code = Number(message.error_code ?? 0);
      latestDevice.last_received_at = nowIso();
      broadcastToWeb("capture_result", message);
      broadcastToWeb("status", latestStatus);
      broadcastToWeb("device", latestDevice);
      break;

    case "error":
      latestStatus.state = message.state || "ERROR";
      latestStatus.error_code = Number(message.error_code ?? 900);
      latestStatus.last_capture_result = "NG";
      latestDevice.last_received_at = nowIso();
      broadcastToWeb("error", message);
      broadcastToWeb("status", latestStatus);
      broadcastToWeb("device", latestDevice);
      break;

    case "heartbeat":
      latestDevice.last_received_at = nowIso();
      broadcastToWeb("device", latestDevice);
      break;

    default:
      broadcastToWeb("raw", message);
      break;
  }
}

function handleEsp32Data(chunk) {
  esp32Buffer += chunk.toString("utf8");

  let index;
  while ((index = esp32Buffer.indexOf("\n")) >= 0) {
    const line = esp32Buffer.slice(0, index).trim();
    esp32Buffer = esp32Buffer.slice(index + 1);
    if (!line) continue;

    try {
      handleEsp32Message(JSON.parse(line));
    } catch (error) {
      log("Invalid JSON line:", line);
      broadcastToWeb("error", {
        error_code: 402,
        message: "Invalid JSON received from ESP32",
        raw: line
      });
    }
  }

  if (esp32Buffer.length > 8192) {
    log("Receive buffer overflow. Clearing buffer.");
    esp32Buffer = "";
  }
}

function markEsp32Disconnected() {
  latestDevice = { ...latestDevice, connected: false, last_received_at: nowIso() };
  latestStatus = { ...latestStatus, state: "DISCONNECTED", wifi_connected: false };
  broadcastToWeb("device", latestDevice);
  broadcastToWeb("status", latestStatus);
}

const tcpServer = net.createServer((socket) => {
  if (esp32Socket && !esp32Socket.destroyed) {
    esp32Socket.destroy();
  }

  esp32Socket = socket;
  esp32Buffer = "";

  latestDevice = {
    connected: true,
    device_id: "",
    fw_version: "",
    remote_address: `${socket.remoteAddress}:${socket.remotePort}`,
    connected_at: nowIso(),
    last_received_at: nowIso()
  };
  latestStatus = { ...latestStatus, state: "CONNECTED", wifi_connected: true };

  log("ESP32 connected:", latestDevice.remote_address);
  broadcastToWeb("device", latestDevice);
  broadcastToWeb("status", latestStatus);

  socket.setKeepAlive(true, 10000);
  socket.on("data", handleEsp32Data);
  socket.on("close", () => {
    log("ESP32 disconnected");
    if (esp32Socket === socket) esp32Socket = null;
    markEsp32Disconnected();
  });
  socket.on("error", (error) => {
    log("ESP32 socket error:", error.message);
    if (esp32Socket === socket) esp32Socket = null;
    markEsp32Disconnected();
  });
});

tcpServer.listen(TCP_PORT, HOST, () => {
  log(`TCP socket server listening on ${HOST}:${TCP_PORT}`);
});

function sendJson(res, statusCode, payload) {
  res.writeHead(statusCode, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store"
  });
  res.end(JSON.stringify(payload, null, 2));
}

function serveStatic(req, res) {
  const urlPath = req.url.split("?")[0];
  const filePath = urlPath === "/" ? "/index.html" : urlPath;
  const fullPath = path.normalize(path.join(PUBLIC_DIR, filePath));

  if (!fullPath.startsWith(PUBLIC_DIR)) {
    sendJson(res, 403, { error: "Forbidden" });
    return;
  }

  fs.readFile(fullPath, (error, data) => {
    if (error) {
      sendJson(res, 404, { error: "Not Found" });
      return;
    }

    const ext = path.extname(fullPath).toLowerCase();
    const contentTypes = {
      ".html": "text/html; charset=utf-8",
      ".css": "text/css; charset=utf-8",
      ".js": "application/javascript; charset=utf-8",
      ".json": "application/json; charset=utf-8"
    };

    res.writeHead(200, {
      "Content-Type": contentTypes[ext] || "application/octet-stream",
      "Cache-Control": "no-store"
    });
    res.end(data);
  });
}

const httpServer = http.createServer((req, res) => {
  const urlPath = req.url.split("?")[0];

  if (req.method === "GET" && urlPath === "/api/status") {
    sendJson(res, 200, { device: latestDevice, status: latestStatus });
    return;
  }

  if (req.method === "POST" && urlPath === "/api/capture") {
    if (!esp32Socket || esp32Socket.destroyed) {
      sendJson(res, 503, {
        result: "NG",
        error_code: 400,
        message: "ESP32 is not connected"
      });
      return;
    }

    const requestId = `req-${Date.now()}`;
    const ok = sendToEsp32({
      type: "capture_request",
      request_id: requestId
    });

    sendJson(res, ok ? 202 : 500, ok ? {
      result: "ACCEPTED",
      request_id: requestId
    } : {
      result: "NG",
      error_code: 401,
      message: "Failed to send capture_request"
    });
    return;
  }

  if (req.method === "POST" && urlPath === "/api/heartbeat") {
    const ok = sendToEsp32({ type: "heartbeat" });
    sendJson(res, ok ? 200 : 503, {
      result: ok ? "OK" : "NG",
      message: ok ? "heartbeat sent" : "ESP32 is not connected"
    });
    return;
  }

  serveStatic(req, res);
});

const wss = new WebSocket.Server({ server: httpServer });

wss.on("connection", (ws) => {
  clients.add(ws);
  ws.send(JSON.stringify({ type: "device", payload: latestDevice }));
  ws.send(JSON.stringify({ type: "status", payload: latestStatus }));

  ws.on("close", () => clients.delete(ws));
  ws.on("error", () => clients.delete(ws));
});

httpServer.listen(HTTP_PORT, HOST, () => {
  log(`Web server listening on http://localhost:${HTTP_PORT}`);
});
