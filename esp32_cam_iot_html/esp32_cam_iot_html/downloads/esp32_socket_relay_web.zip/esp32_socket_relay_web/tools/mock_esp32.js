const net = require("net");
const HOST = process.env.RELAY_HOST || "127.0.0.1";
const TCP_PORT = Number(process.env.TCP_PORT || 5000);
let captureCount = 0;
let socket = null;
let buffer = "";

function send(message) {
  if (!socket || socket.destroyed) return;
  socket.write(JSON.stringify(message) + "\n");
}

function connect() {
  socket = net.createConnection({ host: HOST, port: TCP_PORT }, () => {
    console.log("mock ESP32 connected");
    send({ type: "hello", device_id: "mock-esp32-cam-001", fw_version: "mock-0.1.0" });

    setInterval(() => {
      send({
        type: "status",
        state: "MONITORING",
        wifi_connected: true,
        motion_detected: Math.random() > 0.7,
        light_level: Math.floor(Math.random() * 4096),
        capture_count: captureCount,
        last_capture_result: captureCount > 0 ? "OK" : "NONE",
        error_code: 0
      });
    }, 1000);
  });

  socket.on("data", (chunk) => {
    buffer += chunk.toString("utf8");
    let index;
    while ((index = buffer.indexOf("\n")) >= 0) {
      const line = buffer.slice(0, index).trim();
      buffer = buffer.slice(index + 1);
      if (!line) continue;

      const message = JSON.parse(line);
      console.log("received:", message);

      if (message.type === "capture_request") {
        captureCount += 1;
        setTimeout(() => {
          send({
            type: "capture_result",
            request_id: message.request_id,
            result: "OK",
            capture_count: captureCount,
            error_code: 0
          });
        }, 800);
      }

      if (message.type === "heartbeat") {
        send({ type: "heartbeat" });
      }
    }
  });

  socket.on("close", () => {
    console.log("connection closed. reconnecting...");
    setTimeout(connect, 1500);
  });

  socket.on("error", (error) => console.log("socket error:", error.message));
}

connect();
