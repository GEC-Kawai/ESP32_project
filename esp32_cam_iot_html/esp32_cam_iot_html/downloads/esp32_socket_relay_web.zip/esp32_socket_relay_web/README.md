# ESP32-CAM ソケット中継サーバ＋Web画面

## 概要

この一式は、ESP32-CAM課題で渡邉側が提供するWeb側環境です。

- ブラウザはWeb画面を表示します。
- Web画面は中継サーバとHTTP/WebSocketで通信します。
- ESP32は中継サーバへTCPソケットで接続します。
- 受講者はESP32側のTCPソケット通信を実装します。

## 構成

```text
esp32_socket_relay_web/
  server.js
  package.json
  public/
    index.html
    styles.css
    app.js
  tools/
    mock_esp32.js
  README.md
```

## 必要環境

- Node.js 18以降推奨

## セットアップ

```bash
npm install
```

## 起動

```bash
npm start
```

起動後、ブラウザで以下へアクセスします。

```text
http://localhost:3000
```

TCPソケットサーバは以下で待ち受けます。

```text
0.0.0.0:5000
```

ESP32側は、PCのIPアドレスとポート5000へTCP接続してください。

## 動作確認用モック

ESP32実機なしで動作確認する場合は、別ターミナルで以下を実行します。

```bash
npm run mock:esp32
```

## ESP32との通信仕様

通信方式はTCPソケットです。

メッセージはJSON Lines形式です。

- 1メッセージ = 1行のJSON
- 末尾に `\n` を付与
- UTF-8

### ESP32 → サーバ: hello

```json
{"type":"hello","device_id":"esp32-cam-001","fw_version":"0.1.0"}
```

### ESP32 → サーバ: status

```json
{"type":"status","state":"MONITORING","wifi_connected":true,"motion_detected":false,"light_level":1234,"capture_count":3,"last_capture_result":"OK","error_code":0}
```

### サーバ → ESP32: capture_request

```json
{"type":"capture_request","request_id":"req-0001"}
```

### ESP32 → サーバ: capture_result

```json
{"type":"capture_result","request_id":"req-0001","result":"OK","capture_count":4,"error_code":0}
```

### ESP32 → サーバ: error

```json
{"type":"error","state":"ERROR","error_code":200,"message":"Camera initialization failed"}
```

## Web画面でできること

- ESP32接続状態の表示
- device_id / fw_version / remote addressの表示
- 最新status表示
- 撮影要求送信
- heartbeat送信
- 受信ログ表示

## 受講者が実装するESP32側の主な処理

- Wi-Fi接続
- TCPソケット接続
- hello送信
- status周期送信
- capture_request受信
- カメラ撮影処理
- capture_result送信
- error送信
- 切断時の再接続

## 注意

TCPはストリーム通信なので、1回のrecvで1メッセージ全体が届くとは限りません。
JSON Lines形式のため、改行コード `\n` を区切りとして受信バッファを処理してください。
